package ${IJ_BASE_PACKAGE}.blob;

public class Cliente {
    private String name;
    private int età;

    public Cliente(String name, int età) {
        this.name = name;
        this.età = età;
    }
    public String getName() {
        return name;
    }
    public int getEtà() {
        return età;
    }
}