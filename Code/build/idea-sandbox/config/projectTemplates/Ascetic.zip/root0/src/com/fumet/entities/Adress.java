package ${IJ_BASE_PACKAGE}.entities;

public class Adress {

    private String country;
    private String city;
    private String civicNumber;
    private String zipCode;

    public Adress() {
    }

    public Adress(String country, String city, String civicNumber, String zipCode) {
        this.country = country;
        this.city = city;
        this.civicNumber = civicNumber;
        this.zipCode = zipCode;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCivicNumber() {
        return civicNumber;
    }

    public void setCivicNumber(String civicNumber) {
        this.civicNumber = civicNumber;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }
}