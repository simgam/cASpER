package ${IJ_BASE_PACKAGE}.entities;

public class Customer {

    private String name;
    private Phone tel;

    public Customer(String name)
    {    this.name=name;
    }

    public String getName()
    {    return name;
    }

    public String getMobilePhoneNumber(Phone p) {
        return tel.getAreaCode() + ") " +
                tel.getPrefix() + "-" +
                tel.getNumber();
    }
}