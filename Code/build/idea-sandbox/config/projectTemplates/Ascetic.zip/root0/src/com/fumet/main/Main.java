package ${IJ_BASE_PACKAGE}.main;

import ${IJ_BASE_PACKAGE}.entities.Adress;
import ${IJ_BASE_PACKAGE}.entities.Customer;
import ${IJ_BASE_PACKAGE}.entities.Phone;
import ${IJ_BASE_PACKAGE}.registration.IdentityChecker;

public class Main {

    public static void main(String[] args) {

        Adress adress = new Adress();
        Phone phone = new Phone(args[2]);
        Customer customer = new Customer(phone + "");
        IdentityChecker checker = new IdentityChecker();
        checker.checkCustomerId(customer);

    }

}
