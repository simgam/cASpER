package ${IJ_BASE_PACKAGE}.registration;

import ${IJ_BASE_PACKAGE}.entities.Customer;
import ${IJ_BASE_PACKAGE}.entities.Phone;

public class IdentityChecker {


    public boolean checkCustomerId(Customer customer){

        String customerPhoneNumber = customer.getMobilePhoneNumber(new Phone("123456"));
        if(sendSmsToCustomer(customerPhoneNumber)){
            return true;
        } else {
            return false;
        }

    }

    private boolean sendSmsToCustomer(String customerPhoneNumber) {
        return true;
    }

}
