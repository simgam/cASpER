package ${IJ_BASE_PACKAGE}.blob;

public class BankAccount {
    private double balance;
    private int accountNumber;

    public BankAccount(double balance, int accountNumber) {
        this.balance = balance;
        this.accountNumber = accountNumber;
    }

    public double getBalance() {
        return balance;
    }
}