package ${IJ_BASE_PACKAGE}.blob;

public class Ristorante {
    public String nome_Ristorante;

    public Ristorante(String nome_Ristorante) {
        this.nome_Ristorante = nome_Ristorante;
    }

    public String getNome_Ristorante() {
        return nome_Ristorante;
    }

    public void setNome_Ristorante(String nome_Ristorante) {
        this.nome_Ristorante = nome_Ristorante;
    }
}